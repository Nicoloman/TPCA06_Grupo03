<?php
### This file is part of the dictionaries-common package.
### It has been automatically generated.
### DO NOT EDIT!
$SQSPELL_APP = array (
  'American English (ispell)' => 'ispell -a    -B -d american',
  'British English (ispell)' => 'ispell -a    -B -d british'
);
